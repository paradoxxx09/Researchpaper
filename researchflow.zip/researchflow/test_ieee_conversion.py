#!/usr/bin/env python3
"""Quick script to validate IEEE citation conversion."""

import asyncio

from backend.services.download_service import DownloadService

async def main() -> None:
    service = DownloadService()
    content = (
        "Climate Change Research represents a rapidly evolving field (Middendorf et al., 2020; "
        "Amolegbe et al., 2022). Additional study highlights regional impacts (Johnson & Lee, 2021)."
    )
    references = [
        {
            "authors": ["Middendorf, G.", "Schneider, M."],
            "year": "2020",
            "title": "Impacts of Climate Change"
        },
        {
            "authors": ["Amolegbe, A.", "Johnson, B."],
            "year": "2022",
            "title": "Climate Adaptation Strategies"
        },
        {
            "authors": ["Johnson, P.", "Lee, C."],
            "year": "2021",
            "title": "Regional Climate Analysis"
        }
    ]
    converted = await service._replace_in_text_citations_with_style(content, references, "ieee")
    print("Original:\n", content)
    print("Converted:\n", converted)

if __name__ == "__main__":
    asyncio.run(main())
