# Researchpaper

Add text-to-text translation feature using LibreTranslate API (free, no key required)
